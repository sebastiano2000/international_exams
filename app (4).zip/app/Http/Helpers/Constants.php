<?php 

define('ADMIN',1);
